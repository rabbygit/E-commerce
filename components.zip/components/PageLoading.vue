<template>
  <v-container>
    <v-row>
      <div style="min-height: 50vh ; min-width: 100%;" class="d-flex align-center justify-center">
        <div>
          <v-progress-circular :width="3" color="red" indeterminate></v-progress-circular>
        </div>
      </div>
    </v-row>
  </v-container>
</template>

<script>
export default {};
</script>

<style>
</style>