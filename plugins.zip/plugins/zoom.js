import Vue from 'vue'
import ImageMagnifier from "vue-image-magnifier"
Vue.use(ImageMagnifier)