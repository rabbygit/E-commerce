export default async function ({ store, redirect ,$axios}) {
    // console.log(store.state.auth.setUser)
    // if (store.state.auth.loggedIn && store.state.auth.user && !store.state.auth.setUser) {
    //     await $axios.post("api/auth/setUser" , store.state.auth.user )
    //     store.state.auth.setUser = true
    // }
}